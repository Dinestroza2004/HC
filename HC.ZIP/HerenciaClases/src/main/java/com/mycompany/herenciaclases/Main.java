/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.herenciaclases;

/**
 *
 * @author Pc
 */
// Clase principal
public class Main {
    public static void main(String[] args) {
        // Crear objetos de cada subclase
        Circulo c = new Circulo("rojo", 5.0);
        Linea l = new Linea("azul", 10.0);
        Triangulo t = new Triangulo("verde", 3.0);
        Cuadrado cu = new Cuadrado("amarillo", 4.0);

        // Llamadas a los métodos dibujar de cada subclase
        c.dibujar();
        l.dibujar();
        t.dibujar();
        cu.dibujar();
    }
}
