/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.herenciaclases;

/**
 *
 * @author Pc
 */
public class Formas {
    // Clase base: Formas

    protected String color;

    // Constructor
    public Formas(String color) {
        this.color = color;
    }

    // Método de la clase base para establecer el color
    public void establecerColor(String nuevoColor) {
        color = nuevoColor;
    }

    // Método virtual para dibujar (será sobreescrito en las subclases)
    public void dibujar() {
        System.out.println("Dibujando una forma.");
    }
}

// Subclase: Circulo
class Circulo extends Formas {
    private final double radio;

    // Constructor
    public Circulo(String color, double radio) {
        super(color);
        this.radio = radio;
    }

    // Sobreescritura del método dibujar
    @Override
    public void dibujar() {
        System.out.println("Dibujando un circulo.");
    }

    // Método específico para calcular el radio
    public double calcularRadio() {
        return radio;
    }
}

// Subclase: Linea
class Linea extends Formas {

    // Constructor
    public Linea(String color, double largo) {
        super(color);
    }

    // Sobreescritura del método dibujar
    @Override
    public void dibujar() {
        System.out.println("Dibujando una linea.");
    }
}

// Subclase: Triangulo
class Triangulo extends Formas {
    private final double angulo;

    // Constructor
    public Triangulo(String color, double angulo) {
        super(color);
        this.angulo = angulo;
    }

    // Sobreescritura del método dibujar
    @Override
    public void dibujar() {
        System.out.println("Dibujando un triangulo.");
    }

    // Método específico para calcular el área
    public double calcularArea() {
        // Ejemplo simplificado
        return 0.5 * angulo;
    }
}

// Subclase: Cuadrado
class Cuadrado extends Formas {
    private final double area;

    // Constructor
    public Cuadrado(String color, double area) {
        super(color);
        this.area = area;
    }

    // Sobreescritura del método dibujar
    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado.");
    }

    // Método específico para calcular el área
    public double calcularArea() {
        return area;
    }
}


